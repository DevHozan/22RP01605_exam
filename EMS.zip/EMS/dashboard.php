<?php
session_start();
include("connect.php");
if(!isset($_SESSION['username'])){
    header("Location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    
</head>
<body>

    <nav>
        
   <a href=""><?= $_SESSION['username'] ?></a> 
   <a href="logout.php">Logout</a>
    
    </nav>

    <div class="welcome">
        Welcome to EMS
    </div>
    <?php
    if(!isset($_GET['update'])){  // this is to prevent this form to exist when an admin is updating
?>
  <div class="register" id="register">
    <fieldset>
        <legend>Record an Employee</legend>

        <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
            <input type="text" name="employee_name" placeholder="Type employee_name" required><br>
            <input type="email" name="email" placeholder="Type employee_email" required><br>
            <input type="text" name="phone" placeholder="Type employee_phone" required><br>
            <input type="text" name="position" placeholder="Type your position" required><br>
            <textarea name="address"></textarea><br>
            <input type="submit" name="record" value="Record"><br> 
        </form>
        
    </fieldset>
    </div>
<?php
    }
  
?>

    <div class="update" id="update"> 
    <!-- this is the dev that will be displayed when an admin is going to update an employee -->

    <?php
    if(isset($_GET['update'])&&$_GET['id']){ 
        $id=$_GET['id'];
        $sel="SELECT* FROM employees  where id='$id' order by created_at desc";
                $save=mysqli_query($conn,$sel);
                if(mysqli_num_rows($save)>0){
                    while($row=mysqli_fetch_assoc($save)){

                        ?>

                          <fieldset>
        <legend>Update an Employee Info</legend>

        <form method="POST" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
        <input type="hidden" name="id" value="<?=$row['id'] ?>"required><br>

            <input type="text" name="employee_name" value="<?=$row['employee_name'] ?>" placeholder="Type employee_name" required><br>
            <input type="email" name="email" value="<?=$row['email'] ?>" placeholder="Type employee_email" required><br>
            <input type="text" name="phone" value="<?=$row['phone'] ?>" placeholder="Type employee_phone" required><br>
            <input type="text" name="position" value="<?=$row['position'] ?>" placeholder="Type your position" required><br>
            <textarea name="address"><?=$row['address'] ?>"</textarea><br>
            <input type="submit" name="update_employee" value="update"><br> <!-- will be handled on line 208--->
        </form>
        
    </fieldset>

   

                        <?php


                      
                    }
                }else{
                    echo"No user found";
                }

                
    
    }

?>
    </div>




<?php
    if(isset($_POST['record'])){ // this the backend handler to record an employee in the table
    function test_input($data){
        $data=htmlentities($data);
        $data=trim($data);
        $data=stripslashes($data);
        return $data;
    }

    $employee_name=test_input($_POST['employee_name']);
    $email=test_input($_POST['email']);
    $phone=test_input($_POST['phone']);
    $position=test_input($_POST['position']);
    $address=test_input($_POST['address']);

    if(!empty($employee_name) || !empty($email) || !empty($phone)||!empty($position)||!empty($address)){

        if(preg_match('/^[a-zA-Z]+$/',$employee_name)){
            if(preg_match('/^[0-9]{12}+$/',$phone) ||preg_match('/^[0-9]{10}+$/',$phone)||preg_match('/^[0-9]{13}+$/',$phone)){  
                if(preg_match('/^[a-zA-Z]+$/',$position)){   
        
            if(FILTER_VAR($email,FILTER_VALIDATE_EMAIL)){


                $in="INSERT INTO employees(employee_name,email,phone,position,address) VALUES(?,?,?,?,?)";
                $stmt=$conn->prepare($in);
                $stmt->bind_param('sssss',$employee_name,$email,$phone,$position,$address);
               
                
              if($stmt->execute()){
                echo "user is recorded";
              }else{
                echo "user is not recorded ".mysqli_error($conn);
              }



            }else{
                echo 'Invalid password';
            }

        }else{ 
            echo"write valid position";
        }
    }else{ 
        echo"write valid phone number like 250791724884";
    }
        }else{
            echo "Please enter valid username";
        }



    }else{
        echo "Please enter your username and password";
    }


}
?>
<!-- this is the table that shows employees recorded -->

<table border="1px">
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Employee Email</th>
            <th>phone</th>
            <th>position</th>
            <th>address</th>
            <th colspan="2">action</th>
        </tr>
    </thead>
    <tbody>
        <?php
    $sel="SELECT* FROM employees order by created_at desc";
                $save=mysqli_query($conn,$sel);
                if(mysqli_num_rows($save)>0){
                    while($row=mysqli_fetch_assoc($save)){
                       
                    echo" <tr>
                     <td> {$row['employee_name']}</td> ";
                     echo"<td> {$row['email']}</td> ";
                     echo"<td> {$row['phone']}</td> ";
                     echo"<td> {$row['position']}</td> ";
                     echo"<td> {$row['address']}</td>";
                     echo"<td> <a href='dashboard.php?update&&id=".$row['id']."'>update</a></td>";
                     echo"<td> <a href='dashboard.php?delete&&id=".$row['id']."'>delete</a></td>";
                    echo  "</tr>";
                       
                     
                      
                      
                    }
                }else{
                    echo"No user found";
                }

                ?>
    </tbody>


</table>

<?php
if(isset($_POST['update_employee'])){  // this is the backend handler or the codes that will updated an updated employee
    function test_input($data){
        $data=htmlentities($data);
        $data=trim($data);
        $data=stripslashes($data);
        return $data;
    }

    $employee_name=test_input($_POST['employee_name']);
    $email=test_input($_POST['email']);
    $phone=test_input($_POST['phone']);
    $position=test_input($_POST['position']);
    $address=test_input($_POST['address']);
    $id=test_input($_POST['id']);
    

    if(!empty($employee_name) || !empty($email) || !empty($phone)||!empty($position)||!empty($address)){

        if(preg_match('/^[a-zA-Z]+$/',$employee_name)){
            if(preg_match('/^[0-9]{12}+$/',$phone) ||preg_match('/^[0-9]{10}+$/',$phone)||preg_match('/^[0-9]{13}+$/',$phone)){  
                if(preg_match('/^[a-zA-Z]+$/',$position)){   
        
            if(FILTER_VAR($email,FILTER_VALIDATE_EMAIL)){


                $in=" UPDATE employees SET employee_name=? ,email=?,phone=?,position=?,address=? WHERE id=?";
                $stmt=$conn->prepare($in);
                $stmt->bind_param('sssssi',$employee_name,$email,$phone,$position,$address,$id);
               
                
              if($stmt->execute()){
                echo "user {$employee_name} is updated";
                header("location:dashboard.php");
              }else{
                echo "user is not recorded ".mysqli_error($conn);
              }


            }else{
                echo 'Invalid password';
            }

        }else{ 
            echo"write valid position";
        }
    }else{ 
        echo"write valid phone number like 250791724884";
    }
        }else{
            echo "Please enter valid username";
        }



    }else{
        echo "Please enter your username and password";
    }

 
}


if(isset($_GET['delete'])){ // codes to delete an employee
    $id=$_GET['id'];
    $del="DELETE FROM employees WHERE id='$id'";
    $qer=mysqli_query($conn,$del);
    if($qer){
        header("Location:dashboard.php");
    }else{
        echo"something went wrong";
    }
}

?>



    
</body>
</html>