<?php
try{
$conn=new mysqli("localhost","root","","nexttech_portal_22RP01605");
if(!$conn){
    echo "you are not connected to database";
}
}catch(Exception $e){
    echo "error connecting to database".$e->getMessage();
}